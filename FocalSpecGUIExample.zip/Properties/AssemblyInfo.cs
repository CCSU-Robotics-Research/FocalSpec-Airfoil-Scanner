﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AssemblyInfo.cs" company="FocalSpec Ltd">
//   FocalSpec Ltd 2015
// </copyright>
// <summary>
//   Version information.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("GuiExample")]
[assembly: AssemblyDescription("FSSDK GUI example project")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("FocalSpec Oy")]
[assembly: AssemblyProduct("GuiExample")]
[assembly: AssemblyCopyright("Copyright © 2016 - 2019 FocalSpec")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("fb48f185-5b2b-473e-84bd-ecd022c3ba2a")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("2.1.0.7")]
[assembly: AssemblyFileVersion("2.1.0.7")]

